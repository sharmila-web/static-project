// ---------- Sample data (replace with your own or fetch from an API) ----------
// Optional fields: img (image path/URL shown on the card) and note (e.g. "Suitable for freezing")
const RECIPES = [
  { name: "Spiced apple bread and butter pudding", meal: ["Dessert"], serves: 4, mins: 57, diet: ["Vegetarian", "Nut-free"], cuisine: ["British"], cond: [], icon: "🍎", bg: "#fbe3d6" },
  { name: "Beetroot hummus", meal: ["Sauce/dressing", "Starter", "Snack", "Side dish"], serves: 2, mins: 5, diet: ["Vegan", "Vegetarian", "Dairy-free", "Egg-free", "Gluten-free", "Nut-free", "Low-sugar"], cuisine: ["Middle Eastern and North African"], cond: ["High cholesterol", "High blood pressure"], icon: "🫘", bg: "#f3d1dc" },
  { name: "Patatas bravas", note: "suitable for freezing", img: "", meal: ["Side dish", "Snack", "Starter"], serves: 4, mins: 60, diet: ["Vegan", "Vegetarian", "Dairy-free", "Egg-free", "Gluten-free", "Nut-free", "Low-fat"], cuisine: ["Greek, Italian and Mediterranean"], cond: ["High cholesterol"], icon: "🥔", bg: "#fdebc2" },
  { name: "Spicy carrot and lentil soup", meal: ["Soup", "Main meal"], serves: 3, mins: 22, diet: ["Vegan", "Vegetarian", "Dairy-free", "Egg-free", "Gluten-free", "Nut-free", "Low-fat", "Low-sugar"], cuisine: ["Indian and South Asian"], cond: ["Diabetes", "High cholesterol", "High blood pressure"], icon: "🥕", bg: "#fcd9b6" },
  { name: "Strawberry and chocolate beetroot cake", meal: ["Dessert"], serves: 16, mins: 65, diet: ["Vegetarian"], cuisine: ["British"], cond: [], icon: "🍓", bg: "#f6cfd3" },
  { name: "Avocado and poached egg on toast", meal: ["Breakfast", "Main meal"], serves: 2, mins: 10, diet: ["Vegetarian", "Dairy-free", "Nut-free", "Low-sugar"], cuisine: ["American"], cond: ["High cholesterol"], icon: "🥑", bg: "#dcebc8" },
  { name: "Mediterranean vegetable lasagne", meal: ["Main meal"], serves: 4, mins: 80, diet: ["Vegetarian", "Nut-free"], cuisine: ["Greek, Italian and Mediterranean"], cond: ["High blood pressure"], icon: "🍝", bg: "#fbd7c4" },
  { name: "'Marry me' chicken", meal: ["Main meal"], serves: 2, mins: 30, diet: ["Gluten-free", "Egg-free", "Nut-free", "Low-sugar"], cuisine: ["Greek, Italian and Mediterranean"], cond: ["Diabetes"], icon: "🍗", bg: "#fde0b0" },
  { name: "Jerk chicken burgers", note: "Not suitable for freezing", img: "", meal: ["Main meal"], serves: 6, mins: 55, diet: ["Dairy-free", "Egg-free", "Nut-free"], cuisine: ["African-Caribbean"], cond: ["High cholesterol"], icon: "🍔", bg: "#f5d3b3" },
  { name: "Mango and lime mousse", note: "Not suitable for freezing", img: "", meal: ["Dessert", "Snack"], serves: 4, mins: 10, diet: ["Vegetarian", "Gluten-free", "Nut-free", "Low-fat"], cuisine: ["Thai and South-East Asian"], cond: [], icon: "🥭", bg: "#fff0b3" },
  { name: "Vegetarian bean chilli", note: "Suitable for freezing", img: "", meal: ["Main meal"], serves: 4, mins: 50, diet: ["Vegan", "Vegetarian", "Dairy-free", "Egg-free", "Nut-free", "Low-fat", "Low-sugar"], cuisine: ["Mexican and South American"], cond: ["Diabetes", "High cholesterol", "High blood pressure"], icon: "🌶️", bg: "#f6c9c0" },
  { name: "Wholewheat nachos with guacamole and tomato salsa", note: "Not suitable for freezing", img: "", meal: ["Side dish", "Snack", "Starter"], serves: 4, mins: 35, diet: ["Vegan", "Vegetarian", "Dairy-free", "Egg-free", "Nut-free"], cuisine: ["Mexican and South American"], cond: ["High cholesterol"], icon: "🌮", bg: "#f9e1a8" },
  { name: "Thai green fish curry", meal: ["Main meal"], serves: 4, mins: 25, diet: ["Dairy-free", "Egg-free", "Gluten-free", "Nut-free"], cuisine: ["Thai and South-East Asian"], cond: ["High blood pressure"], icon: "🍛", bg: "#d4ecd0" },
  { name: "Overnight oats with berries", meal: ["Breakfast"], serves: 1, mins: 5, diet: ["Vegetarian", "Egg-free", "Low-fat", "Nut-free"], cuisine: ["Nordic"], cond: ["High cholesterol"], icon: "🫐", bg: "#dcd6f2" }
];

const FILTERS = {
  diet:    { label: "Dietary preferences", options: ["Dairy-free", "Egg-free", "Gluten-free", "Low-fat", "Low-sugar", "Nut-free", "Vegan", "Vegetarian"] },
  cuisine: { label: "Cuisine", options: ["African-Caribbean", "American", "British", "Chinese and East Asian", "East European", "Greek, Italian and Mediterranean", "Indian and South Asian", "Mexican and South American", "Middle Eastern and North African", "Nordic", "Thai and South-East Asian"] },
  meal:    { label: "Meal type", options: ["Breakfast", "Dessert", "Main meal", "Salad", "Sauce/dressing", "Side dish", "Snack", "Soup", "Starter"] },
  cond:    { label: "Condition specific", options: ["Diabetes", "High blood pressure", "High cholesterol"] },
  time:    { label: "Cooking time", options: ["Under 20 mins", "20 to 45 mins", "Over 45 mins"] }
};

const QUICK = [
  { label: "Chicken recipes",    keyword: "chicken" },
  { label: "Family favourites",  filters: { meal: ["Main meal"] } },
  { label: "Healthy favourites", filters: { diet: ["Low-fat", "Low-sugar"] } },
  { label: "Quick meals",        filters: { time: ["Under 20 mins"] } },
  { label: "Vegetarian ideas",   filters: { diet: ["Vegetarian"] } }
];

const ICON_MEAL = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3v7a2 2 0 0 0 2 2v9M10 3v7a2 2 0 0 1-2 2M8 3v7M17 21V3c-2 1-3 4-3 8h3"/></svg>';
const ICON_PEOPLE = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 2.9-6 6.5-6s6.5 2.5 6.5 6zM16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.3c2.2.7 3.5 2.6 3.5 5.7"/></svg>';
const ICON_CLOCK = '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';

const PER_PAGE = 8;
const state = { keyword: "", filters: emptyFilters(), page: 1 };

function emptyFilters() {
  return Object.fromEntries(Object.keys(FILTERS).map(k => [k, []]));
}

// ---------- Helpers ----------
const $ = id => document.getElementById(id);
const slug = s => s.toLowerCase().replace(/[^a-z0-9]+/g, "-");

function formatTime(m) {
  const h = Math.floor(m / 60), r = m % 60;
  if (!h) return `${m} minutes`;
  const hr = `${h} ${h === 1 ? "hour" : "hours"}`;
  return r ? `${hr} ${r} minutes` : hr;
}
function timeBucket(m) {
  return m < 20 ? "Under 20 mins" : m <= 45 ? "20 to 45 mins" : "Over 45 mins";
}

// ---------- Filtering ----------
function matches(r) {
  const kw = state.keyword.trim().toLowerCase();
  if (kw && !r.name.toLowerCase().includes(kw)) return false;
  const f = state.filters;
  // Dietary preferences: recipe must satisfy ALL selected
  if (!f.diet.every(d => r.diet.includes(d))) return false;
  if (!f.cond.every(c => r.cond.includes(c))) return false;
  // Cuisine, meal type, time: recipe must match ANY selected
  if (f.cuisine.length && !f.cuisine.some(c => r.cuisine.includes(c))) return false;
  if (f.meal.length && !f.meal.some(m => r.meal.includes(m))) return false;
  if (f.time.length && !f.time.includes(timeBucket(r.mins))) return false;
  return true;
}

// ---------- Rendering ----------
function buildFilters() {
  $("groups").innerHTML = Object.entries(FILTERS).map(([key, g]) => `
    <fieldset>
      <legend>${g.label}</legend>
      ${g.options.map(o => `
        <label class="check">
          <input type="checkbox" data-group="${key}" value="${o}" id="${key}-${slug(o)}"> ${o}
        </label>`).join("")}
    </fieldset>`).join("");
}

function buildQuick() {
  $("quick").innerHTML = QUICK.map((q, i) => `<button type="button" data-i="${i}">${q.label}</button>`).join("");
}

function syncCheckboxes() {
  document.querySelectorAll("#groups input").forEach(cb => {
    cb.checked = state.filters[cb.dataset.group].includes(cb.value);
  });
}

function renderChips() {
  const all = Object.values(state.filters).flat();
  $("active").hidden = all.length === 0;
  $("chips").innerHTML = all.map(f => `<span class="chip">${f}</span>`).join("");
}

function render() {
  const list = RECIPES.filter(matches);
  const pages = Math.max(1, Math.ceil(list.length / PER_PAGE));
  state.page = Math.min(state.page, pages);
  const slice = list.slice((state.page - 1) * PER_PAGE, state.page * PER_PAGE);

  const filtered = state.keyword.trim() || Object.values(state.filters).some(a => a.length);
  $("resultsTitle").textContent = filtered
    ? `Showing ${list.length} result${list.length === 1 ? "" : "s"}`
    : `Showing all ${list.length} results`;

  $("grid").innerHTML = slice.length ? slice.map(r => `
    <a class="card" href="#" onclick="return false">
      <div class="thumb" style="background:${r.bg}">${r.img ? `<img src="${r.img}" alt="${r.name}" loading="lazy">` : `<span aria-hidden="true">${r.icon}</span>`}</div>
      <div class="card-body">
        <h3>${r.name}</h3>
        <div class="info">${ICON_MEAL}<span>${r.meal.join(", ")}</span></div>
        <div class="info">${ICON_PEOPLE}<span>${r.serves}${r.note ? ` (${r.note})` : ""} servings</span></div>
        <div class="info">${ICON_CLOCK}<span>${formatTime(r.mins)}</span></div>
      </div>
    </a>`).join("")
    : `<div class="empty"><strong>No recipes match.</strong><br>Remove a filter or try a different keyword.</div>`;

  renderPager(pages);
  renderChips();
}

function renderPager(pages) {
  if (pages <= 1) { $("pager").innerHTML = ""; return; }
  let html = `<button data-p="${state.page - 1}" ${state.page === 1 ? "disabled" : ""} aria-label="Previous page">‹</button>`;
  for (let p = 1; p <= pages; p++) {
    html += `<button data-p="${p}" ${p === state.page ? 'aria-current="page"' : ""}>${p}</button>`;
  }
  html += `<button data-p="${state.page + 1}" ${state.page === pages ? "disabled" : ""} aria-label="Next page">›</button>`;
  $("pager").innerHTML = html;
}

// ---------- Events ----------
function init() {
  buildFilters();
  buildQuick();

  $("searchForm").addEventListener("submit", e => {
    e.preventDefault();
    state.keyword = $("keyword").value;
    state.filters = emptyFilters();
    document.querySelectorAll("#groups input:checked").forEach(cb => state.filters[cb.dataset.group].push(cb.value));
    state.page = 1;
    render();
  });

  $("toggleFilters").addEventListener("click", e => {
    const open = e.target.getAttribute("aria-expanded") === "true";
    e.target.setAttribute("aria-expanded", String(!open));
    $("filters").hidden = open;
  });

  $("clearKeyword").addEventListener("click", () => {
    $("keyword").value = ""; state.keyword = ""; state.page = 1; render();
    $("keyword").focus();
  });

  $("clearAll").addEventListener("click", () => {
    state.filters = emptyFilters(); state.page = 1;
    syncCheckboxes(); render();
  });

  $("quick").addEventListener("click", e => {
    const btn = e.target.closest("button");
    if (!btn) return;
    const q = QUICK[btn.dataset.i];
    state.keyword = q.keyword || "";
    state.filters = { ...emptyFilters(), ...(q.filters || {}) };
    state.page = 1;
    $("keyword").value = state.keyword;
    syncCheckboxes(); render();
  });

  $("pager").addEventListener("click", e => {
    const btn = e.target.closest("button");
    if (!btn || btn.disabled) return;
    state.page = Number(btn.dataset.p);
    render();
    $("resultsTitle").scrollIntoView({ behavior: "smooth" });
  });

  render();
}

init();
